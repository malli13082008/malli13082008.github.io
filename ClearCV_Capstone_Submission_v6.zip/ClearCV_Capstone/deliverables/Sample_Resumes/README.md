# ClearCV sample resumes

These four fictional resumes are provided for testing the ClearCV analyzer. Each role is available as both DOCX and text-based PDF so you can check either upload format.

| File base name | Choose this role in the app |
|---|---|
| `ClearCV_Sample_data_analyst` | Data Analyst |
| `ClearCV_Sample_web_developer` | Web Developer |
| `ClearCV_Sample_ai_engineer` | AI Engineer |
| `ClearCV_Sample_cloud_engineer` | Cloud Engineer |

The names, schools, phone numbers, and email addresses are fictional. These files are for software demonstrations and should not be submitted as a real person's resume.

To try them, run ClearCV and upload one resume at a time. Select the matching role from the table above. The files include the sample role skills so you can see the analyzer's matched-skill result.
